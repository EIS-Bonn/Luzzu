/**
 * 
 */
package eu.diachron.qualitymetrics.intrinsic.semanticaccuracy.helper.evaluation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.apache.jena.riot.Lang;
import org.apache.jena.riot.RDFDataMgr;
import org.openrdf.query.resultio.QueryResultFormat;

import slib.sml.sm.core.utils.SMConstants;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;
import com.hp.hpl.jena.graph.Triple;
import com.hp.hpl.jena.query.Dataset;
import com.hp.hpl.jena.query.DatasetFactory;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.query.ResultSetFormatter;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.rdf.model.impl.StatementImpl;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;

import de.unibonn.iai.eis.diachron.datatypes.Pair;
import de.unibonn.iai.eis.diachron.technques.probabilistic.ReservoirSampler;
import de.unibonn.iai.eis.luzzu.properties.PropertyManager;
import de.unibonn.iai.eis.luzzu.semantics.utilities.Commons;
import eu.diachron.qualitymetrics.intrinsic.semanticaccuracy.helper.PredicateClusteringIndexing;
import eu.diachron.qualitymetrics.utilities.SerialisableTriple;

/**
 * @author Jeremy Debattista
 * 
 */
public class EvaluationHelper {

	
	public static void main(String[] args) throws IOException{
//		createDBPediaPropertiesTriples();
//		calculatePrecisionRecallAndF1();
//		getTypeCount();
//		createRecallEvaluationTriples();
//		createMissingRecallEvaluationTriples();
		evaluation();
//		diffSimMeasureEvaluation();
//		qualityEvaluation();
//		diffSimMeasureEvaluationSmallFraction();
//		createSmallDump();
//		paulheimOutlier();
	}
	
	
	public static void paulheimOutlier() throws FileNotFoundException{
		String mainFile = "/Users/jeremy/Dropbox/outlier_exp/saints.nt";
		String outlierFile = "/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/paulheim.nt";
		String savedFile = "/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/paulheimSaved.ttl";
		
		Model mainmodel = RDFDataMgr.loadModel(mainFile);
		Model outlierModel = RDFDataMgr.loadModel(outlierFile);
		
		Model evalModel = ModelFactory.createDefaultModel();
		
		int counter = 0;
		for(Statement s : outlierModel.listStatements().toList()){
			String sbjT = s.asTriple().getSubject().getURI();
			String objT = s.asTriple().getObject().getURI();
			
			String query = "PREFIX dbp:<http://dbpedia.org/property/> SELECT * WHERE { OPTIONAL { <"+sbjT+"> a ?st .} . OPTIONAL { <"+objT+"> a ?ot .} . <"+sbjT+">  dbp:saint <"+objT+"> . }";
			
			Query q = QueryFactory.create(query);
			QueryExecution qexec = QueryExecutionFactory.create(q, mainmodel);
			ResultSet rs = qexec.execSelect();
			
			while (rs.hasNext()){
				QuerySolution qs = rs.next();
				Resource uri = evalModel.createResource("urn:"+UUID.randomUUID().toString());
				evalModel.add(uri, evalModel.createProperty("uri:object"), evalModel.createResource(objT));
				evalModel.add(uri, evalModel.createProperty("uri:subject"), evalModel.createResource(sbjT));

				evalModel.add(uri, evalModel.createProperty("uri:objectType"), (qs.get("ot") != null) ? qs.get("ot").asResource() : OWL.Thing);
				evalModel.add(uri, evalModel.createProperty("uri:subjectType"), (qs.get("st") != null) ? qs.get("st").asResource() : OWL.Thing);
				
			}
			counter++;
		}

		Resource uri = evalModel.createResource("urn:"+UUID.randomUUID().toString());
		evalModel.add(uri, evalModel.createProperty("uri:totalOutliers"), evalModel.createTypedLiteral(counter));
		
		
		RDFDataMgr.write(new FileOutputStream(new File(savedFile)), evalModel, Lang.TTL);

		resultFile = RDFDataMgr.loadModel(savedFile);
		
		double pv = precisionValue("/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/tagged/allPossibleIncorrect.nt");
		System.out.println("Precision All Possible Incorrect Triples: " + pv);
		double rv = recallValue("/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/tagged/allPossibleIncorrect.nt");
		System.out.println("Recall All Possible Incorrect Triples: " + rv);
		double f1Measure = 2 * ((pv * rv) / (pv + rv));
		System.out.println("F1 Incorrect Object Type : " + f1Measure);
	}
	
	public static void createSmallDump() throws FileNotFoundException{
		String file = "/Users/jeremy/Dropbox/outlier_exp/saints.nt";
		String savedfile = "/Users/jeremy/Dropbox/outlier_exp/small.nt";

		String sampleTypes = "/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/tagged/smalldump.ttl";
		
		Model data = RDFDataMgr.loadModel(file);
		Model smp = RDFDataMgr.loadModel(sampleTypes);
		Model sample = ModelFactory.createDefaultModel();
		
		for (Statement stmt : smp.listStatements().toList()){
			String sbjT = stmt.asTriple().getSubject().getURI();
			String objT = stmt.asTriple().getObject().getURI();
			
			String query = "PREFIX dbp:<http://dbpedia.org/property/> SELECT * WHERE { ?x a <"+sbjT+"> . ?y a <"+objT+"> . ?x dbp:saint ?y . }";
			
			int counter = 0;
			Query q = QueryFactory.create(query);
			QueryExecution qexec = QueryExecutionFactory.create(q, data);
			ResultSet rs = qexec.execSelect();
			
			while (rs.hasNext()){
				QuerySolution qs = rs.next();
				sample.add(qs.getResource("x").asResource(), RDF.type, sample.createResource(sbjT));
				sample.add(qs.getResource("y").asResource(), RDF.type, sample.createResource(objT));
				sample.add(qs.getResource("x").asResource(), sample.createProperty("http://dbpedia.org/property/author"), qs.getResource("y").asResource());
				counter++;
				if (counter == 2) break;
			}
		}
		
		RDFDataMgr.write(new FileOutputStream(new File(savedfile)), sample, Lang.NTRIPLES);
	}
	
	public static void createRecallEvaluationTriples() throws FileNotFoundException{
		String file = "/Users/jeremy/Dropbox/outlier_exp/publisher.nt";
		String evalSampleFile = "/Users/jeremy/Dropbox/outlier_exp/publisher_types_recall_eval.nt";
		
		Model eval = ModelFactory.createDefaultModel();
		Model m = RDFDataMgr.loadModel(file);
		
		Property prop =  m.createProperty("http://dbpedia.org/property/publisher");
			
		String getAllTypes = "PREFIX dbp:<http://dbpedia.org/property/> SELECT * WHERE { ?x dbp:saint ?y . ?x a ?typeSub . ?y a ?typeObj .}";
		Query query = QueryFactory.create(getAllTypes);
		QueryExecution qexec = QueryExecutionFactory.create(query, m);
		ResultSet rs = qexec.execSelect();
		
		while (rs.hasNext()){
			QuerySolution qs = rs.next();
			eval.add(qs.get("typeSub").asResource(), prop, qs.get("typeObj").asResource());
		}
		
		RDFDataMgr.write(new FileOutputStream(new File(evalSampleFile)), eval, Lang.NTRIPLES);
	}
	
	public static void createMissingRecallEvaluationTriples() throws FileNotFoundException{
		String file = "/Users/jeremy/Dropbox/outlier_exp/publisher.nt";
		String evalSampleFile = "/Users/jeremy/Dropbox/outlier_exp/publisher_types_recall_eval_missing.nt";
		
		Model eval = ModelFactory.createDefaultModel();
		Model m = RDFDataMgr.loadModel(file);
		
		Property prop =  m.createProperty("http://dbpedia.org/property/publisher");
		
		String getUnknownTypes = "PREFIX dbp:<http://dbpedia.org/property/> SELECT * WHERE { ?x dbp:saint ?y . OPTIONAL{ ?x a ?typeSub .} OPTIONAL{ ?y a ?typeObj . }  }";
		Query query = QueryFactory.create(getUnknownTypes);
		QueryExecution qexec = QueryExecutionFactory.create(query, m);
		ResultSet rs = qexec.execSelect();
		
		while (rs.hasNext()){
			QuerySolution qs = rs.next();

			if ((qs.get("typeSub") != null) && (qs.get("typeObj") != null)) continue;
			else eval.add((qs.get("typeSub") != null) ? qs.get("typeSub").asResource() : OWL.Thing, prop, (qs.get("typeObj") != null) ? qs.get("typeObj").asResource() : OWL.Thing);
		}
		
		RDFDataMgr.write(new FileOutputStream(new File(evalSampleFile)), eval, Lang.NTRIPLES);

		
	}
	
	public static void createEvaluationTriples() throws FileNotFoundException{
		String file = "/Users/jeremy/Dropbox/outlier_exp/music.trig";
		String evalSampleFile = "/Users/jeremy/Dropbox/outlier_exp/saints_sample_eval.trig";
		

		Model m = RDFDataMgr.loadModel(file);
		
		Property prop =  m.createProperty("http://dbpedia.org/property/author");
				
		String getAllTypes = "PREFIX dbp:<http://dbpedia.org/property/> SELECT * WHERE { ?x dbp:saint ?y . ?x a ?typeSub . ?y a ?typeObj .}";
		Query query = QueryFactory.create(getAllTypes);
		QueryExecution qexec = QueryExecutionFactory.create(query, m);
		ResultSet rs = qexec.execSelect();
		
		Map<Pair<String,String>,Integer> pairs = new HashMap<Pair<String,String>,Integer>();
		Map<String,String> types = new HashMap<String,String>();
		
		List<Pair<String,String>> allPairs = new ArrayList<Pair<String,String>>();
		while (rs.hasNext()){
			QuerySolution qs = rs.next();
			
			types.put(qs.get("x").asResource().getURI(), qs.get("typeSub").asResource().getURI());
			types.put(qs.get("y").asResource().getURI(), qs.get("typeObj").asResource().getURI());

			
			Pair p = new Pair<String,String>(qs.get("typeSub").asResource().getURI(), qs.get("typeObj").asResource().getURI());
			
			if (pairs.containsKey(p)) 
				pairs.put(p,pairs.get(p) + 1);
			else {
				pairs.put(p,1);
				allPairs.add(p);
			}

		}
		
		Map<Pair<String,String>, ReservoirSampler<SerialisableTriple>> res = new HashMap<Pair<String,String>, ReservoirSampler<SerialisableTriple>>();
		
		for(Pair<String,String> s : pairs.keySet()){
			int size = pairs.get(s);
			if (size < 10) res.put(s, new ReservoirSampler<SerialisableTriple>(size, true));
			else res.put(s, new ReservoirSampler<SerialisableTriple>(10, true));
		}
		
		qexec = QueryExecutionFactory.create(query, m);
		rs = qexec.execSelect();
		while (rs.hasNext()){
			QuerySolution qs = rs.next();
			Pair p = new Pair<String,String>(qs.get("typeSub").asResource().getURI(), qs.get("typeObj").asResource().getURI());
			
			Triple t = new Triple(qs.get("x").asNode(), prop.asNode() , qs.get("y").asNode());
			SerialisableTriple st = new SerialisableTriple(t);
			res.get(p).add(st);
		}
		
		
		Dataset d = DatasetFactory.createMem();
		while (res.size() > 4){
			Resource g = Commons.generateURI();
			Model _m = ModelFactory.createDefaultModel();
			
			Random r = new Random();
			List<Integer> chosen;
			
			for (int i = 0; i <= 15; i++){
				chosen = new ArrayList<Integer>();
				int rand = r.nextInt(res.size());
				while(chosen.contains(rand)) rand = r.nextInt(res.size());
				chosen.add(rand);
				Pair p = allPairs.get(rand);
				
				Triple t = res.get(p).getItems().get(0).getTriple();
				_m.add(Commons.asRDFNode(t.getSubject()).asResource(), prop, Commons.asRDFNode(t.getObject()));
				_m.add(Commons.asRDFNode(t.getSubject()).asResource(), RDF.type, _m.createResource(types.get(t.getSubject().getURI())).asResource());
				_m.add(Commons.asRDFNode(t.getObject()).asResource(), RDF.type, _m.createResource(types.get(t.getObject().getURI())).asResource());
				
				res.get(p).getItems().remove(0);
				
				if (res.get(p).size() == 0) {
					res.remove(p); 
					allPairs.remove(rand);
				}
			}
			
			
			d.addNamedModel(g.getURI(), _m);
		}
		
		RDFDataMgr.write(new FileOutputStream(new File(evalSampleFile)), d, Lang.TRIG);
	}
	
	public static void createDBPediaPropertiesTriples() throws IOException{
		Model m = ModelFactory.createDefaultModel();
		boolean flag = false;
		int i = 0;
		do{
			String select = Resources.toString(Resources.getResource("getTriples.sparql"), Charsets.UTF_8);
			select = select.replace("%%PROPERTY%%", "publisher");
			select = select.replace("%%OFFSET%%", "OFFSET " + i);
	
			
			Query query = QueryFactory.create(select);
			QueryExecution qexec = QueryExecutionFactory.sparqlService("http://dbpedia.org/sparql", query);
	
			ResultSet results = qexec.execSelect();
			if (!results.hasNext()) flag = true;
			while (results.hasNext()) {
				QuerySolution sol = results.next();
				m.add(sol.getResource("instance"), m.createProperty("http://dbpedia.org/property/publisher"), sol.get("author"));
				m.add(sol.getResource("instance"), RDF.type, sol.get("type"));
				if (sol.get("type2") != null) m.add(sol.getResource("author"), RDF.type, sol.get("type2"));
			}
			qexec.close() ;
			i += 10000;
		} while (!flag);
		m.write(new FileOutputStream(new File("/Users/jeremy/Dropbox/outlier_exp/publisher.nt")), "NT");

	}

	private static Model addUnknownTypes(Model m){
		
		Model _m = ModelFactory.createDefaultModel();
		_m.add(m);
		
//		Property prop =  _m.createProperty("http://dbpedia.org/property/author");
		
		String getUnknownTypes = "PREFIX dbp:<http://dbpedia.org/property/> SELECT * WHERE { ?x dbp:saint ?y . OPTIONAL{ ?x a ?typeSub .} OPTIONAL{ ?y a ?typeObj . }  }";
		Query query = QueryFactory.create(getUnknownTypes);
		QueryExecution qexec = QueryExecutionFactory.create(query, m);
		ResultSet rs = qexec.execSelect();
		
		while (rs.hasNext()){
			QuerySolution qs = rs.next();

			if ((qs.get("typeSub") != null) && (qs.get("typeObj") != null)) continue;
			else _m.add((qs.get("typeSub") != null) ? qs.get("y").asResource() : qs.get("x").asResource(), RDF.type, OWL.Thing);
		}
		

		
		return _m;
	}

	public static void calculatePrecisionRecallAndF1(){
		//Add missing owl types to dataFile
		dataFile = addUnknownTypes(dataFile);
		
		resultFile = RDFDataMgr.loadModel(evaluationDirectory+"evaluation_manual/saints_manual_0-3555_0-996.ttl");
		
//		double pv = precisionValue("incorrect.nt");
//		System.out.println("Precision Incorrect Pairs : " + pv);
//		double rv = recallValue("incorrect.nt");
//		System.out.println("Recall Incorrect Pairs : " + rv);
//		double f1Measure = 2 * ((pv * rv) / (pv + rv));
//		System.out.println("F1 Incorrect Pairs : " + f1Measure);
//		System.out.println("==============");
//		System.out.println();
//		
//		
//		pv = precisionValue("correctObjects.nt");
//		System.out.println("Precision Incorrect Subject Type : " + pv);
//		rv = recallValue("correctObjects.nt");
//		System.out.println("Recall Incorrect Subject Type : " + rv);
//		f1Measure = 2 * ((pv * rv) / (pv + rv));
//		System.out.println("F1 Incorrect Subject Type : " + f1Measure);
//		System.out.println("==============");
//		System.out.println();
//		
//		pv = precisionValue("correctSubjects.nt");
//		System.out.println("Precision Incorrect Object Type : " + pv);
//		rv = recallValue("correctSubjects.nt");
//		System.out.println("Recall Incorrect Object Type : " + rv);
//		f1Measure = 2 * ((pv * rv) / (pv + rv));
//		System.out.println("F1 Incorrect Object Type : " + f1Measure);
//		System.out.println("==============");
//		System.out.println();
		
		double pv = precisionValue("/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/tagged/allPossibleIncorrect.nt");
		System.out.println("Precision All Possible Incorrect Triples: " + pv);
		double rv = recallValue("/Users/jeremy/Dropbox/outlier_exp/evaluation/saints/tagged/allPossibleIncorrect.nt");
		System.out.println("Recall All Possible Incorrect Triples: " + rv);
		double f1Measure = 2 * ((pv * rv) / (pv + rv));
		System.out.println("F1 Incorrect Object Type : " + f1Measure);

	}
	
	private static double precisionValue(String fileName){
		Model manualTypeAnnotation = RDFDataMgr.loadModel(fileName, Lang.N3);
		StmtIterator iter = manualTypeAnnotation.listStatements();
		
		double truePositives = 0.0;
		double falsePositives = 0.0;
		for(Statement s : iter.toList()){
			String getAllStmts =  "SELECT * WHERE { ?x <"+evaluatedProperty.getURI()+"> ?y . ";
			getAllStmts += "?x a <" + s.getSubject().toString() + "> . ";
			getAllStmts += "?y a <" + s.getObject().toString() + "> }";
			
			Query query = QueryFactory.create(getAllStmts);
			QueryExecution qexec = QueryExecutionFactory.create(query, dataFile);
			ResultSet rs = qexec.execSelect();
			
			while (rs.hasNext()){
				QuerySolution qs = rs.next();
				String getOutliers =  "ASK { ";
				getOutliers += "?x <uri:object> <" + qs.get("y").asResource() + "> . ";
				getOutliers += "?x <uri:objectType> <" + s.getObject().toString() + "> . ";
				getOutliers += "?x <uri:subject> <" + qs.get("x").asResource() + "> . ";
				getOutliers += "?x <uri:subjectType> <" + s.getSubject().toString() + "> . }";
				
				Query q1 = QueryFactory.create(getOutliers);
				QueryExecution _qexec = QueryExecutionFactory.create(q1, resultFile);
				if (_qexec.execAsk()) truePositives++;
			}
		}
		
		String getNoSelectedElements =  "SELECT ?y { ?x <uri:totalOutliers> ?y . }";
		Query query = QueryFactory.create(getNoSelectedElements);
		QueryExecution qexec = QueryExecutionFactory.create(query, resultFile);
		ResultSet rs = qexec.execSelect();
		Integer totOut = rs.next().getLiteral("y").getInt();
		falsePositives = (double) totOut - truePositives;
		
		double precisionValue = truePositives / (truePositives + falsePositives);
		return precisionValue;
	}
	
	private static double recallValue(String fileName){
		Model manualTypeAnnotation = RDFDataMgr.loadModel(fileName, Lang.N3);
		StmtIterator iter = manualTypeAnnotation.listStatements();
		
		double truePositives = 0.0;
		double falseNegatives = 0.0;
		for(Statement s : iter.toList()){
			String getAllStmts =  "SELECT * WHERE { ?x <"+evaluatedProperty.getURI()+"> ?y . ";
			getAllStmts += "?x a <" + s.getSubject().toString() + "> . ";
			getAllStmts += "?y a <" + s.getObject().toString() + "> }";
			
			Query query = QueryFactory.create(getAllStmts);
			QueryExecution qexec = QueryExecutionFactory.create(query, dataFile);
			ResultSet rs = qexec.execSelect();
			
			while (rs.hasNext()){
				QuerySolution qs = rs.next();
				String getOutliers =  "ASK { ";
				getOutliers += "?x <uri:object> <" + qs.get("y").asResource() + "> . ";
				getOutliers += "?x <uri:objectType> <" + s.getObject().toString() + "> . ";
				getOutliers += "?x <uri:subject> <" + qs.get("x").asResource() + "> . ";
				getOutliers += "?x <uri:subjectType> <" + s.getSubject().toString() + "> . }";
				
				Query q1 = QueryFactory.create(getOutliers);
				QueryExecution _qexec = QueryExecutionFactory.create(q1, resultFile);
				if (_qexec.execAsk()) truePositives++;
				else falseNegatives++;
			}
		}
		
		double recallValue = truePositives / (truePositives + falseNegatives);
		return recallValue;
	}

	public static void getTypeCount(){
		dataFile = addUnknownTypes(dataFile);
		
		String qs = "PREFIX dbp:<http://dbpedia.org/property/> SELECT DISTINCT ?subtype ?obtype (COUNT(?subtype) as ?cnt) { ?x dbp:saint ?y . ?x a ?subtype . ?y a ?obtype . } GROUP BY ?subtype ?obtype  ORDER BY DESC(?cnt)";
		Query query = QueryFactory.create(qs);
		QueryExecution qexec = QueryExecutionFactory.create(query, dataFile);
		ResultSet rs = qexec.execSelect();
		
		ResultSetFormatter.out(System.out, rs, query);
		
//		qs = "PREFIX dbp:<http://dbpedia.org/property/> SELECT DISTINCT (AVG(?subtype) as ?cnt) { ?x dbp:saint ?y . ?x a ?subtype . ?y a ?obtype . } GROUP BY ?subtype ?obtype  ORDER BY DESC(?cnt)";
//		query = QueryFactory.create(qs);
//		qexec = QueryExecutionFactory.create(query, dataFile);
//		rs = qexec.execSelect();
//		
//		ResultSetFormatter.out(System.out, rs, query);
	}
	
	
	static String directory = "/Users/jeremy/Dropbox/outlier_exp/";
	static String evaluationDirectory = directory + "evaluation/saints/eval_files/";
	static String allPossibleIncorrect = directory + "evaluation/saints/tagged/allPossibleIncorrect.nt";

	static Model resultFile = null;
	static Model dataFile = RDFDataMgr.loadModel(directory+"saints.nt");
	
	static Property evaluatedProperty = ModelFactory.createDefaultModel().createProperty("http://dbpedia.org/property/saint");
	static String csvFile = evaluationDirectory + "prec_rec.csv";
	
	public static void evaluation() throws FileNotFoundException{
		dataFile = addUnknownTypes(dataFile);
		
		Double[] p = new Double[]{0.86,0.86,0.863,0.863,0.865,0.865,0.867,0.867,0.869,0.869}; 
		
		
		
		// manual
//		System.out.println("*** Start of Manual Evaluation ***");
////		Double[] approxD = new Double[]{0.3775, 0.3995, 0.4115, 0.4335, 0.4555, 0.4775}; //author
////		Double[] approxD = new Double[]{0.3, 0.3335, 0.3555, 0.3775, 0.3995, 0.4115, 0.4335, 0.4555, 0.4775, 0.4995}; //author
//		Double[] approxD = new Double[]{0.4995}; //publisher
//		for (Double d : approxD){
//			for(Double d1 : p){
//				System.out.printf("Approx D:%f, P Value:%f - ", d,d1);
//				PredicateClusteringIndexing predicateClustering = new PredicateClusteringIndexing(evaluatedProperty.asResource());
//				predicateClustering.manual = true;
//				predicateClustering.approxD = d;
//				predicateClustering.MIN_FRACTION_OBJ_P = d1;
//				predicateClustering.useTriples = true;
//				String fileName = "saints_manual_"+Double.toString(d).replace('.', '-')+"_"+Double.toString(d1).replace('.', '-');
//				
//				runEvaluation(predicateClustering, fileName);
//				
//				resultFile = RDFDataMgr.loadModel(evaluationDirectory+fileName+".ttl");
//				double precValue = precisionValue(allPossibleIncorrect);
//				double recValue = recallValue(allPossibleIncorrect);
//				System.out.printf("Precision Value:%f, Recall Value:%f - ", precValue,recValue);
//				System.out.println();
//
//				//type,approxD,p,prec,recall
//				File f = new File(csvFile);
//				String evalLine = String.format("%s,%f,%f,%f,%f", "manual",d, d1, precValue, recValue);
//				try {
//					PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
//					out.println(evalLine);
//					out.close();
//				}catch (IOException e){
//					e.printStackTrace();
//				}
//			}
//		}
//		System.out.println("*** End of Manual Evaluation ***");
//		
//		//automatic - using types
		System.out.println("*** Start of Automatic Evaluation - using types ***");
		for(Double d1 : p){
			System.out.printf("P Value:%f - ", d1);

			PredicateClusteringIndexing predicateClustering = new PredicateClusteringIndexing(evaluatedProperty.asResource());
			predicateClustering.manual = false;
			predicateClustering.MIN_FRACTION_OBJ_P = d1;
			predicateClustering.useTriples = false;
			String fileName = "saints_automatic_types_"+Double.toString(d1).replace('.', '-');
			runEvaluation(predicateClustering, fileName);
			
			resultFile = RDFDataMgr.loadModel(evaluationDirectory+fileName+".ttl");
			double precValue = precisionValue(allPossibleIncorrect);
			double recValue = recallValue(allPossibleIncorrect);
			System.out.printf("Precision Value:%f, Recall Value:%f - ", precValue,recValue);
			System.out.println();
			
			//type,approxD,p,prec,recall
			File f = new File(csvFile);
			String evalLine = String.format("%s,%f,%f,%f,%f", "types",predicateClustering.approxD, d1, precValue, recValue);
			try {
				PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
				out.println(evalLine);
				out.close();
			}catch (IOException e){
				e.printStackTrace();
			}
		}
		System.out.println("*** End of Automatic Evaluation - using types ***");

		
//		//automatic - using triples
//		System.out.println("*** Start of Automatic Evaluation - using triples ***");
//		for(Double d1 : p){
//			System.out.printf("P Value:%f - ", d1);
//
//			PredicateClusteringIndexing predicateClustering = new PredicateClusteringIndexing(evaluatedProperty.asResource());
//			predicateClustering.manual = false;
//			predicateClustering.MIN_FRACTION_OBJ_P = d1;
//			predicateClustering.useTriples = true;
//			String fileName = "saints_automatic_triple_"+Double.toString(d1).replace('.', '-');
//			runEvaluation(predicateClustering, fileName);
//			
//			resultFile = RDFDataMgr.loadModel(evaluationDirectory+fileName+".ttl");
//			double precValue = precisionValue(allPossibleIncorrect);
//			double recValue = recallValue(allPossibleIncorrect);
//			System.out.printf("Precision Value:%f, Recall Value:%f - ", precValue,recValue);
//			System.out.println();
//
//			//type,approxD,p,prec,recall
//			File f = new File(csvFile);
//			String evalLine = String.format("%s,%f,%f,%f,%f", "triples",predicateClustering.approxD, d1, precValue, recValue);
//			try {
//				PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
//				out.println(evalLine);
//				out.close();
//			}catch (IOException e){
//				e.printStackTrace();
//			}
//		}
//		System.out.println("*** End of Automatic Evaluation - using triples ***");

		
	}
	
	
	private static void runEvaluation(PredicateClusteringIndexing predicateClustering, String suffix) throws FileNotFoundException{
		runEvaluation(predicateClustering, suffix, dataFile);
	}
	
	static int totalTriples = 0;
	
	private static void runEvaluation(PredicateClusteringIndexing predicateClustering, String suffix, Model dataModel) throws FileNotFoundException{
		totalTriples = 0;
		Map<String,String> typesMap = new HashMap<String,String>();

		PropertyManager.getInstance().addToEnvironmentVars("baseURI", "http://dbpedia.org");
		
		for(Statement s : dataModel.listStatements().toList()){
			Resource p = Commons.asRDFNode(s.asTriple().getPredicate()).asResource();
			RDFNode o = Commons.asRDFNode(s.asTriple().getObject());
			
			if (o.isLiteral()) continue;
			
			if (p.equals(RDF.type)) {
				typesMap.put(s.asTriple().getSubject().getURI(), s.asTriple().getObject().getURI());
			}
			else {
				totalTriples++;
				predicateClustering.addTriple(s.asTriple());
			}
		}
		
		predicateClustering.findOutliers(typesMap);

		Model m = predicateClustering.evaluationModel(typesMap);
		m.write(new FileOutputStream(new File(evaluationDirectory+suffix+".ttl")), "TURTLE");
	}
	
	
	static String csvSimMeasureFile = evaluationDirectory + "prec_rec_sim_measure.csv";

	public static void diffSimMeasureEvaluation() throws FileNotFoundException{
		dataFile = addUnknownTypes(dataFile);
		
		String[] ici = new String[]{
				SMConstants.FLAG_ICI_SANCHEZ_2011,
				SMConstants.FLAG_ICI_ZHOU_2008,
				SMConstants.FLAG_ICI_SECO_2004
		};
		String[] sim = new String[]{ 
				 SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_MAZANDU_2012,
				 SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998,
				 SMConstants.FLAG_SIM_PAIRWISE_DAG_EDGE_STOJANOVIC_2001,
				 SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_JACCARD_IC
		};
		

		
		for(String i : ici){
			for(String s : sim){
				PredicateClusteringIndexing predicateClustering = new PredicateClusteringIndexing(evaluatedProperty.asResource(), s , i);
				predicateClustering.manual = true;
				predicateClustering.MIN_FRACTION_OBJ_P = 0.4;
				predicateClustering.useTriples = true;
				predicateClustering.approxD = 0.2;
				
				String fileName = "saints_"+predicateClustering.sim+"_"+predicateClustering.ici;
				runEvaluation(predicateClustering, fileName);
				
				resultFile = RDFDataMgr.loadModel(evaluationDirectory+fileName+".ttl");
				double precValue = precisionValue(allPossibleIncorrect);
				double recValue = recallValue(allPossibleIncorrect);
				System.out.printf("Precision Value:%f, Recall Value:%f - ", precValue,recValue);
				System.out.println();
				
				//type,approxD,p,prec,recall
				File f = new File(csvSimMeasureFile);
				String evalLine = String.format("%s,%s,%s,%f,%f,%f", "smallfraction",predicateClustering.sim, predicateClustering.ici, predicateClustering.approxD, precValue, recValue);
				try {
					PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
					out.println(evalLine);
					out.close();
				}catch (IOException e){
					e.printStackTrace();
				}
			}
		}
		
		
	}
	
	
	public static void diffSimMeasureEvaluationSmallFraction() throws FileNotFoundException{
		dataFile = addUnknownTypes(dataFile);
		
		String sim = SMConstants.FLAG_ICI_SANCHEZ_2011; //FLAG_ICI_SECO_2004; //FLAG_ICI_ZHOU_2008; //FLAG_ICI_SANCHEZ_2011
		String ici = SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_SIM_IC_2010;//SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_MAZANDU_2012; //FLAG_SIM_PAIRWISE_DAG_EDGE_LEACOCK_CHODOROW_1998; //FLAG_SIM_PAIRWISE_DAG_EDGE_STOJANOVIC_2001; //FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998

		PredicateClusteringIndexing predicateClustering = new PredicateClusteringIndexing(evaluatedProperty.asResource(), sim, ici);
		predicateClustering.manual = false;
		predicateClustering.MIN_FRACTION_OBJ_P = 0.96;
		predicateClustering.useTriples = false;

		
		String fileName = "saints_"+predicateClustering.sim+"_"+predicateClustering.ici;
		runEvaluation(predicateClustering, fileName);
		
		resultFile = RDFDataMgr.loadModel(evaluationDirectory+fileName+".ttl");
		double precValue = precisionValue(allPossibleIncorrect);
		double recValue = recallValue(allPossibleIncorrect);
		System.out.printf("Precision Value:%f, Recall Value:%f - ", precValue,recValue);
		System.out.println();
		
		//type,approxD,p,prec,recall
		File f = new File(csvSimMeasureFile);
		String evalLine = String.format("%s,%s,%s,%f,%f,%f", "smallfraction",predicateClustering.sim, predicateClustering.ici, predicateClustering.approxD, precValue, recValue);
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
			out.println(evalLine);
			out.close();
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	
	public static void qualityEvaluation() throws FileNotFoundException{
		
		// start with some currP (eg 0.992)
		// evaluate and get precision and recall
		// real quality: 1 - (true positives {removed outliers} / total)
		// approx quality: 1 - (totalOutliers / total)
		// increase (if removed outliers > totalOutliers/2) | decrease (otherwise)
		// currP by some fraction 
		// repeat until the approx quality is not really improving
		
		
		String csvQualityFile = directory + "evaluation/publishers/quality/quality_measure.csv";
		String initialDataFile = directory + "evaluation/publishers/quality/publisher.nt";
		Model dataModel = RDFDataMgr.loadModel(initialDataFile); 
		Double lastQualityValue = -1.0;
		dataModel = addUnknownTypes(dataModel);
		int counter = 0;
		boolean stop = false;
		boolean possibleNextStop = false;
		
		double currP = 0.85;//approxP(dataModel);
		do{
			PredicateClusteringIndexing predicateClustering = new PredicateClusteringIndexing(evaluatedProperty.asResource());
			predicateClustering.manual = false;
			predicateClustering.MIN_FRACTION_OBJ_P = currP;
			predicateClustering.useTriples = false;
			predicateClustering.sim = SMConstants.FLAG_ICI_ZHOU_2008; 
			predicateClustering.ici = SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_MAZANDU_2012;
			
			
			String fileName = "saints_quality_"+counter;
			runEvaluation(predicateClustering, fileName, dataModel);
			
			resultFile = RDFDataMgr.loadModel(evaluationDirectory+fileName+".ttl");
			double precValue = precisionValue(allPossibleIncorrect);
			double recValue = recallValue(allPossibleIncorrect);
			
			long currModelSize = dataModel.size();
			dataModel = removeTriples(allPossibleIncorrect, dataModel);
			long modModelSize = dataModel.size();
			int removedTriples = (int) (currModelSize - modModelSize);
			double realQualityValue = 1.0 - ((double) removedTriples / (double) totalTriples);
			double qualityValue = 1.0 - ((double)getNumberOfOutliersDetected() / (double)totalTriples);
			
			System.out.println(predicateClustering.approxD + " " + realQualityValue + " " + qualityValue);
			
			if (qualityValue == 1.0){
				stop = true;
			}
			else if (Math.abs(Math.abs(lastQualityValue) - Math.abs(qualityValue)) < 0.00000001){
				stop = true;
			} 
			else if (removedTriples == 0){
				if (possibleNextStop) stop = true;
				currP = approxP(dataModel) - 0.1;
				possibleNextStop = true;
			}
			else {
//				int nextTriples = totalTriples - removedTriples;
//				//we might need to changep 
				currP = approxP(dataModel);
				possibleNextStop = false;
			}
			
			lastQualityValue = qualityValue;
			
			//p,approxD,totalTriples,triplesRemoved,qv, real quality value
			File f = new File(csvQualityFile);
			String evalLine = String.format("%f,%f,%f,%f,%d,%d,%f,%f", predicateClustering.MIN_FRACTION_OBJ_P, predicateClustering.approxD, precValue, recValue,totalTriples,removedTriples,qualityValue,realQualityValue);
			try {
				PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(f, true)));
				out.println(evalLine);
				out.close();
			}catch (IOException e){
				e.printStackTrace();
			}
			counter++;
			
			dataModel.write(new FileOutputStream(new File(directory + "evaluation/publishers/quality/cleaned_"+fileName+".nt")), Lang.NT.getLabel());
		} while(!stop);
	}
	
	
	private static int getNumberOfOutliersDetected(){
		String getOutliers =  "Select ?y { ";
		getOutliers += "?x <uri:totalOutliers> ?y . }";
		Query q1 = QueryFactory.create(getOutliers);
		QueryExecution _qexec = QueryExecutionFactory.create(q1, resultFile);
		ResultSet rs = _qexec.execSelect();
		if (rs.hasNext())
			return rs.next().getLiteral("y").getInt();
		
		return 0;
	}
	
	private static Model removeTriples(String fileName, Model model){
		Model returnModel = ModelFactory.createDefaultModel();
		returnModel.add(model);
		Model manualTypeAnnotation = RDFDataMgr.loadModel(fileName, Lang.N3);
		StmtIterator iter = manualTypeAnnotation.listStatements();
		
		for(Statement s : iter.toList()){
			String getAllStmts =  "SELECT * WHERE { ?x <"+evaluatedProperty.getURI()+"> ?y . ";
			getAllStmts += "?x a <" + s.getSubject().toString() + "> . ";
			getAllStmts += "?y a <" + s.getObject().toString() + "> }";
			
			Query query = QueryFactory.create(getAllStmts);
			QueryExecution qexec = QueryExecutionFactory.create(query, model);
			ResultSet rs = qexec.execSelect();
			
			while (rs.hasNext()){
				QuerySolution qs = rs.next();
				String getOutliers =  "ASK { ";
				getOutliers += "?x <uri:object> <" + qs.get("y").asResource() + "> . ";
				getOutliers += "?x <uri:objectType> <" + s.getObject().toString() + "> . ";
				getOutliers += "?x <uri:subject> <" + qs.get("x").asResource() + "> . ";
				getOutliers += "?x <uri:subjectType> <" + s.getSubject().toString() + "> . }";
				
				Query q1 = QueryFactory.create(getOutliers);
				QueryExecution _qexec = QueryExecutionFactory.create(q1, resultFile);
				if (_qexec.execAsk()) {
					returnModel.remove(new StatementImpl(qs.get("x").asResource(), evaluatedProperty, qs.get("y").asResource()));
				}
			}
		}
		
		return returnModel;
	}	
	
	private static double approxP(Model datamodel){
		int avg = 0;
		
		Model df = ModelFactory.createDefaultModel();
		df.add(datamodel);
		
		df = addUnknownTypes(df);
		
		String qs = "PREFIX dbp:<http://dbpedia.org/property/> SELECT DISTINCT ?subtype ?obtype (COUNT(?subtype) as ?cnt) { ?x dbp:saint ?y . ?x a ?subtype . ?y a ?obtype . } GROUP BY ?subtype ?obtype  ORDER BY DESC(?cnt)";
		Query query = QueryFactory.create(qs);
		QueryExecution qexec = QueryExecutionFactory.create(query, dataFile);
		ResultSet rs = qexec.execSelect();
		
		int counter = 0;
		while(rs.hasNext()){
			avg += rs.next().getLiteral("cnt").getInt();
			counter++;
		}
		
		
		double m = (double) avg / (double) counter;
		
		return Math.abs(((double)(m - (df.size()/3))/(double)(df.size()/3)));
		
		
	}
	
}
