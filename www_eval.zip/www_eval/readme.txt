README
======

In this folder you will find the used property dumps (author and publisher) and the tagged dumps. You will also find the Evaluation class that was used.

In order to download the metric, please pull https://github.com/diachron/quality . The metric can be found under the lod-qualitymetrics-intrinsic module