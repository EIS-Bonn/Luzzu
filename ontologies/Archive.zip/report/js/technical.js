jQuery(document).ready(function(){
      $('.ti').show();
      $('.menu span.ti-menu').addClass('active');
})
