jQuery(document).ready(function(){
    
    $('div.details.ontologies div.term h3 span.menu span').addClass('active');
	$('div.details.ontologies div.term div div').show();
	
    $('.inuse').show();
    $('.menu span.inuse-menu').addClass('active');
    
    $('.otherinfo').show();
    $('.menu span.otherinfo-menu').addClass('active');

})

